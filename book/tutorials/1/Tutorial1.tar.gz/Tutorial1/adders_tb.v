`timescale 1ns / 1ps

module adder_tb;

// Signals for 1-bit adders
reg a, b, cin;
wire sum_ha, cout_ha;
wire sum_fa, cout_fa;
wire sum_fa_ha, cout_fa_ha;

// Signals for 4-bit adder
reg [3:0] a4, b4;
reg cin4;
wire [3:0] S4;
wire cout4;

integer i;

// Instantiate all modules
half_adder dut_ha (.a(a), .b(b), .S(sum_ha), .cout(cout_ha));
full_adder dut_fa (.a(a), .b(b), .cin(cin), .S(sum_fa), .cout(cout_fa));
full_adder_with_ha dut_fa_ha (.a(a), .b(b), .cin(cin), .S(sum_fa_ha), .cout(cout_fa_ha));
adder_4bit dut_4bit (.a(a4), .b(b4), .cin(cin4), .S(S4), .cout(cout4));

initial begin
    $dumpfile("adder_tb.vcd");
    $dumpvars(0, adder_tb);

    // Initialize
    a = 0; b = 0; cin = 0;
    a4 = 0; b4 = 0; cin4 = 0;

    // =====================
    // Test Half Adder
    // =====================
    $display("\n=== Half Adder Test ===");
    $display(" a | b || S | cout");
    $display("---+---++---+-----");
    
    for (i = 0; i < 4; i = i + 1) begin
        {b, a} = i[1:0];
        #10;
        $display(" %b | %b || %b |  %b", a, b, sum_ha, cout_ha);
    end

    // =====================
    // Test Full Adder
    // =====================
    $display("\n=== Full Adder Test ===");
    $display(" a | b | cin || S | cout");
    $display("---+---+-----++---+-----");
    
    for (i = 0; i < 8; i = i + 1) begin
        {cin, b, a} = i[2:0];
        #10;
        $display(" %b | %b |  %b  || %b |  %b", a, b, cin, sum_fa, cout_fa);
    end

    // =====================
    // Test Full Adder with Half Adders
    // =====================
    $display("\n=== Full Adder (using Half Adders) Test ===");
    $display(" a | b | cin || S | cout");
    $display("---+---+-----++---+-----");
    
    for (i = 0; i < 8; i = i + 1) begin
        {cin, b, a} = i[2:0];
        #10;
        $display(" %b | %b |  %b  || %b |  %b", a, b, cin, sum_fa_ha, cout_fa_ha);
    end

    // =====================
    // Test 4-bit Adder
    // =====================
    $display("\n=== 4-bit RCA Adder Test ===");
    $display("   A   +    B   + cin =   S   + cout | Expected");
    $display("-------+--------+-----+-------+------+---------");

    // Test case 1: 0 + 0
    a4 = 4'd0; b4 = 4'd0; cin4 = 0; #10;
    $display(" %4b + %4b +  %b  = %4b +  %b   | %2d", a4, b4, cin4, S4, cout4, a4+b4+cin4);

    // Test case 2: 5 + 3
    a4 = 4'd5; b4 = 4'd3; cin4 = 0; #10;
    $display(" %4b + %4b +  %b  = %4b +  %b   | %2d", a4, b4, cin4, S4, cout4, a4+b4+cin4);

    // Test case 3: 15 + 1 (overflow)
    a4 = 4'd15; b4 = 4'd1; cin4 = 0; #10;
    $display(" %4b + %4b +  %b  = %4b +  %b   | %2d", a4, b4, cin4, S4, cout4, a4+b4+cin4);

    // Test case 4: 15 + 15
    a4 = 4'd15; b4 = 4'd15; cin4 = 0; #10;
    $display(" %4b + %4b +  %b  = %4b +  %b   | %2d", a4, b4, cin4, S4, cout4, a4+b4+cin4);

    // Test case 5: 7 + 8 + 1
    a4 = 4'd7; b4 = 4'd8; cin4 = 1; #10;
    $display(" %4b + %4b +  %b  = %4b +  %b   | %2d", a4, b4, cin4, S4, cout4, a4+b4+cin4);

    // Test case 6: Random tests
    $display("\n--- Random Tests ---");
    for (i = 0; i < 5; i = i + 1) begin
        a4 = $random % 16;
        b4 = $random % 16;
        cin4 = $random % 2;
        #10;
        $display(" %4b + %4b +  %b  = %4b +  %b   | %2d", a4, b4, cin4, S4, cout4, a4+b4+cin4);
    end

    $display("\n=== All Tests Complete ===\n");
    $finish;
end

endmodule
