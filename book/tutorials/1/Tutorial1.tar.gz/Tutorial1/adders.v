/* 1-bit adders */

module half_adder(a, b, S, cout);
input a;
input b;

output S;
output cout;

xor(S, a, b);
and(cout, a, b);

endmodule


module full_adder(a, b, cin, S, cout);
input a;
input b;
input cin;
output S;
output cout;

assign S = a ^ b ^ cin;
assign cout = (a&b) ^ (b&cin) ^ (a&cin);

endmodule


module full_adder_with_ha (a, b, cin, S, cout);
input a;
input b;
input cin;
output S;
output cout;

wire w1;
wire w2;
wire w3;

half_adder ha1(.a(a), .b(b), .S(w1), .cout(w2) );
half_adder ha2(.a(w1), .b(cin), .S(S), .cout(w3) );
or(cout, w3, w2);

endmodule


/* 4-bit RCA adder */

module adder_4bit(a, b, cin, S, cout);
input [3:0] a;
input [3:0] b;
input cin;
output [3:0] S;
output cout;

wire c1;
wire c2;
wire c3;

full_adder add1 (.a(a[0]), .b(b[0]), .cin(cin), .S(S[0]), .cout(c1));
full_adder add2 (.a(a[1]), .b(b[1]), .cin(c1), .S(S[1]), .cout(c2));
full_adder add3 (.a(a[2]), .b(b[2]), .cin(c2), .S(S[2]), .cout(c3));
full_adder add4 (.a(a[3]), .b(b[3]), .cin(c3), .S(S[3]), .cout(cout));
 

endmodule